angular.module('demo.sqlite.ctrl', [])

  .controller('SqliteCtrl', function ($scope, $log, $cordovaPreferences) {

  });
